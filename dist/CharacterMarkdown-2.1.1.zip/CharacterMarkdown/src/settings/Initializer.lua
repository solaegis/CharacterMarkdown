-- CharacterMarkdown v2.1.1 - Settings Initializer
-- Handles settings initialization with proper SavedVariables (ESO Guideline Compliant)
-- Author: solaegis
-- COMPLIANCE FIX: Added GetWorldName() for server-specific settings (EU/NA/PTS separation)

CharacterMarkdown = CharacterMarkdown or {}
CharacterMarkdown.Settings = CharacterMarkdown.Settings or {}
CharacterMarkdown.Settings.Initializer = {}

local CM = CharacterMarkdown

-- =====================================================
-- INITIALIZATION
-- =====================================================

function CharacterMarkdown.Settings.Initializer:Initialize()
    CM.DebugPrint("SETTINGS", "Initializing settings system...")
    
    -- Initialize account-wide settings
    self:InitializeAccountSettings()
    
    -- Initialize per-character data
    self:InitializeCharacterData()
    
    -- Sync format to core
    if CharacterMarkdown.currentFormat then
        CharacterMarkdown.currentFormat = CharacterMarkdownSettings.currentFormat
    end
    
    CM.DebugPrint("SETTINGS", "Settings initialized successfully")
    CM.DebugPrint("SETTINGS", "includeChampionPoints:", CharacterMarkdownSettings.includeChampionPoints)
    CM.DebugPrint("SETTINGS", "currentFormat:", CharacterMarkdownSettings.currentFormat)
    
    return true
end

-- =====================================================
-- ACCOUNT-WIDE SETTINGS (SERVER-SPECIFIC)
-- =====================================================

function CharacterMarkdown.Settings.Initializer:InitializeAccountSettings()
    CM.DebugPrint("SETTINGS", "Initializing account-wide settings...")
    
    -- CRITICAL FIX: ESO automatically handles server separation in SavedVariables
    -- Structure: CharacterMarkdownSettings["Default"]["@AccountName"]["$AccountWide"]
    -- DO NOT manually create server nesting - ESO's system does this
    
    -- Initialize saved variables table (ESO handles nested structure)
    CharacterMarkdownSettings = CharacterMarkdownSettings or {}
    
    -- Access the settings directly (ESO manages server/account nesting internally)
    local settings = CharacterMarkdownSettings
    
    local defaults = CharacterMarkdown.Settings.Defaults
    
    -- Check version for migrations
    local savedVersion = settings.settingsVersion
    local isFirstRun = (savedVersion == nil)
    
    CM.DebugPrint("SETTINGS", "First run:", isFirstRun)
    CM.DebugPrint("SETTINGS", "Saved version:", savedVersion)
    
    -- Set version
    settings.settingsVersion = 1
    
    -- Initialize all settings with defaults if not present
    -- (Guideline: use nil checks, don't blindly overwrite)
    
    -- Format
    if settings.currentFormat == nil then
        settings.currentFormat = defaults.FORMAT.currentFormat
    end
    
    -- Validate format
    if not defaults:IsValidFormat(settings.currentFormat) then
        settings.currentFormat = defaults.FORMAT.currentFormat
    end
    
    -- Core sections
    for key, defaultValue in pairs(defaults.CORE) do
        if settings[key] == nil then
            settings[key] = defaultValue
            CM.DebugPrint("SETTINGS", "Set default:", key, "=", defaultValue)
        end
    end
    
    -- Extended sections
    for key, defaultValue in pairs(defaults.EXTENDED) do
        if settings[key] == nil then
            settings[key] = defaultValue
            CM.DebugPrint("SETTINGS", "Set default:", key, "=", defaultValue)
        end
    end
    
    -- Link settings
    for key, defaultValue in pairs(defaults.LINKS) do
        if settings[key] == nil then
            settings[key] = defaultValue
            CM.DebugPrint("SETTINGS", "Set default:", key, "=", defaultValue)
        end
    end
    
    -- Skill filters
    for key, defaultValue in pairs(defaults.SKILL_FILTERS) do
        if settings[key] == nil then
            settings[key] = defaultValue
            CM.DebugPrint("SETTINGS", "Set default:", key, "=", defaultValue)
        end
    end
    
    -- Equipment filters
    for key, defaultValue in pairs(defaults.EQUIPMENT_FILTERS) do
        if settings[key] == nil then
            settings[key] = defaultValue
            CM.DebugPrint("SETTINGS", "Set default:", key, "=", defaultValue)
        end
    end
    
    -- Validate quality setting
    if not defaults:IsValidQuality(settings.minEquipQuality) then
        settings.minEquipQuality = defaults.EQUIPMENT_FILTERS.minEquipQuality
        CM.DebugPrint("SETTINGS", "Reset invalid quality to default")
    end
    
    -- Settings are already in CharacterMarkdownSettings - no need to sync
    
    -- Run migrations if needed
    if not isFirstRun and savedVersion then
        self:MigrateFromVersion(savedVersion)
    end
    
    CM.DebugPrint("SETTINGS", "Account settings initialized")
end

-- =====================================================
-- PER-CHARACTER DATA
-- =====================================================

function CharacterMarkdown.Settings.Initializer:InitializeCharacterData()
    CM.DebugPrint("SETTINGS", "Initializing character data...")
    
    -- Ensure saved variables table exists
    CharacterMarkdownData = CharacterMarkdownData or {}
    
    -- Initialize custom notes
    if CharacterMarkdownData.customNotes == nil then
        CharacterMarkdownData.customNotes = CharacterMarkdown.Settings.Defaults.NOTES.customNotes
        CM.DebugPrint("SETTINGS", "Set default custom notes")
    end
    
    CM.DebugPrint("SETTINGS", "Character data initialized")
end

-- =====================================================
-- RESET TO DEFAULTS
-- =====================================================

function CharacterMarkdown.Settings.Initializer:ResetToDefaults()
    CM.Info("Resetting all settings to defaults...")
    
    local defaults = CharacterMarkdown.Settings.Defaults
    
    -- Direct access to settings (ESO handles nesting)
    local settings = CharacterMarkdownSettings
    
    -- Reset format
    settings.currentFormat = defaults.FORMAT.currentFormat
    
    -- Reset core sections
    for key, value in pairs(defaults.CORE) do
        settings[key] = value
    end
    
    -- Reset extended sections
    for key, value in pairs(defaults.EXTENDED) do
        settings[key] = value
    end
    
    -- Reset link settings
    for key, value in pairs(defaults.LINKS) do
        settings[key] = value
    end
    
    -- Reset skill filters
    for key, value in pairs(defaults.SKILL_FILTERS) do
        settings[key] = value
    end
    
    -- Reset equipment filters
    for key, value in pairs(defaults.EQUIPMENT_FILTERS) do
        settings[key] = value
    end
    
    -- Settings are already in CharacterMarkdownSettings - no sync needed
    
    -- Reset custom notes
    CharacterMarkdownData.customNotes = defaults.NOTES.customNotes
    
    -- Sync to core
    if CharacterMarkdown.currentFormat then
        CharacterMarkdown.currentFormat = CharacterMarkdownSettings.currentFormat
    end
    
    CM.Success("All settings reset to defaults")
end

-- =====================================================
-- MIGRATION (Future-proofing)
-- =====================================================

function CharacterMarkdown.Settings.Initializer:MigrateFromVersion(oldVersion)
    CM.DebugPrint("SETTINGS", "Checking migrations from version:", oldVersion)
    
    -- Example migration pattern:
    -- if oldVersion < 1 then
    --     self:MigrateFrom0To1()
    -- end
    
    -- Currently no migrations needed
    CM.DebugPrint("SETTINGS", "No migrations required")
end
